<template>
	<view class="box">
		网站已关闭
	</view>
</template>

<script>
</script>

<style lang="scss">
	.box{
		position: fixed;
		left: 50%;
		top: 50%;
		transform: translate(-50%,-50%);
		font-size: 40rpx;
		font-weight: bold;
		color: #666;
		text-align: center;
	}
</style>
